# Sage Sanctuary Wellness Site 🌿

Rooted in Culture. Designed for Healing. Built for Us.

This is the custom-built website for **Sage Sanctuary Wellness**, a culturally grounded wellness space offering holistic healing through ancestral traditions.

---

## 💻 File Structure

| File | Description |
|-------|-------------|
| `index.html` | The main HTML structure of the website |
| `style.css` | Stylesheet controlling the site’s design (colors, layout, fonts) |
| `script.js` | JavaScript for smooth scrolling + form validation |
| `README.md` | This project info file |

---

## 🚀 How to Run Locally
1️⃣ Open the `index.html` file in your web browser  
2️⃣ No server or build tools needed (static site)

---

## 🌐 How to Deploy on Netlify
1️⃣ Zip the `sage-sanctuary-site/` folder  
2️⃣ Go to [https://app.netlify.com/drop](https://app.netlify.com/drop)  
3️⃣ Drag + drop the zip  
4️⃣ Netlify will deploy and provide a live URL

---

## 📝 Notes
- This is a plain HTML/CSS/JS site → no build commands required  
- You can connect a custom domain through Netlify  
- For updates: modify your files → create a new ZIP → redeploy

---

## © 2025 Sage Sanctuary Wellness
Rooted in Culture. Designed for Healing. Built for Us.